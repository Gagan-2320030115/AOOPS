package com.example.bankaccount;

public class BankAccount {
    private double balance;

    // Constructor to initialize the balance
    public BankAccount(double initialBalance) {
        this.balance = initialBalance;
    }

    // Synchronized method to ensure thread safety for deposit
    public synchronized void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: " + amount + ", New Balance: " + balance);
        } else {
            System.out.println("Invalid deposit amount: " + amount);
        }
    }
    
    // Synchronized method to ensure thread safety for withdrawal
    public synchronized void withdraw(double amount) {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn: " + amount + ", New Balance: " + balance);
        } else {
            System.out.println("Withdrawal of " + amount + " failed. Insufficient funds or invalid amount.");
        }
    }

    // Synchronized method to get the current balance
    public synchronized double getBalance() {
        return balance;
    }
}

package com.example.bankaccount;

public class Transaction extends Thread {
    private BankAccount account;
    private String transactionType; // "deposit" or "withdraw"
    private double amount;

    public Transaction(BankAccount account, String transactionType, double amount) {
        this.account = account;
        this.transactionType = transactionType;
        this.amount = amount;
    }

    @Override
    public void run() {
        if ("deposit".equalsIgnoreCase(transactionType)) {
            account.deposit(amount);
        } else if ("withdraw".equalsIgnoreCase(transactionType)) {
            account.withdraw(amount);
        } else {
            System.out.println("Invalid transaction type: " + transactionType);
        }
    }
}

/**
 * 
 */
/**
 * 
 */
module NumberPrinter {
}
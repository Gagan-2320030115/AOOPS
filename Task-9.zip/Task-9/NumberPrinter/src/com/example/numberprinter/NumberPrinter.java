package com.example.numberprinter;

class PrintTwo extends Thread {
    public void run() {
        for (int i = 1; i <= 15; i++) {
            if (i % 2 == 0) {
                System.out.println("Divisible by 2: " + i);
            }
        }
    }
}

class PrintThree extends Thread {
    public void run() {
        for (int i = 1; i <= 15; i++) {
            if (i % 3 == 0) {
                System.out.println("Divisible by 3: " + i);
            }
        }
    }
}

class PrintFour extends Thread {
    public void run() {
        for (int i = 1; i <= 15; i++) {
            if (i % 4 == 0) {
                System.out.println("Divisible by 4: " + i);
            }
        }
    }
}

class PrintFive extends Thread {
    public void run() {
        for (int i = 1; i <= 15; i++) {
            if (i % 5 == 0) {
                System.out.println("Divisible by 5: " + i);
            }
        }
    }
}

class PrintNumber extends Thread {
    public void run() {
        for (int i = 1; i <= 15; i++) {
            if (i % 2 != 0 && i % 3 != 0 && i % 4 != 0 && i % 5 != 0) {
                System.out.println("Number: " + i);
            }
        }
    }
}

public class NumberPrinter {
    public static void main(String[] args) {
        PrintTwo printTwo = new PrintTwo();
        PrintThree printThree = new PrintThree();
        PrintFour printFour = new PrintFour();
        PrintFive printFive = new PrintFive();
        PrintNumber printNumber = new PrintNumber();

        printTwo.start();
        printThree.start();
        printFour.start();
        printFive.start();
        printNumber.start();
    }
}

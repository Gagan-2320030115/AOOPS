interface Stack {
    void push(T element);
    T pop();
    T peek();
    boolean isEmpty();
} 

class LinkedListStack implements Stack {
    private LinkedList list;

    public LinkedListStack() {
        list = new LinkedList<>();
    }

    public void push(T element) {
        list.addLast(element);
    }

    public T pop() {
        if (isEmpty()) {
            throw new RuntimeException("Stack is empty");
        }
        return list.removeLast();
    }
    public T peek() {
        if (isEmpty()) {
            throw new RuntimeException("Stack is empty");
        }
        return list.getLast();
    }
    public boolean isEmpty() {
        return list.isEmpty();
    }
}

 class LinkedListStack<T> implements Stack<T> {
    private LinkedList<T> list;

    public LinkedListStack() {
        list = new LinkedList<>();
    }
    public void push(T element) {
        list.addLast(element);
    }
    public T pop() {
        if (isEmpty()) {
            throw new RuntimeException("Stack is empty");
        }
        return list.removeLast();
    }
    public T peek() {
        if (isEmpty()) {
            throw new RuntimeException("Stack is empty");
        }
        return list.getLast();
    }
    public boolean isEmpty() {
        return list.isEmpty();
    }
}